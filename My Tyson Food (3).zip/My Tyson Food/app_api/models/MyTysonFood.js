const mongoose = require('mongoose'); 

// Define the food schema 
const foodSchema = new mongoose.Schema({ 
    code: { type: String, required: true, index: true }, 
    name: { type: String, required: true, index: true }, 
    weight: { type: String, required: true }, 
    pieceCount: { type: String, required: true }, 
    priceperBag: { type: String, required: true }, 
    image: { type: String, required: true }, 
    description: { type: String, required: true } 
}); 
const Food = mongoose.model('trips', foodSchema); 
module.exports = Food; 