import * as tf from '@tensorflow/tfjs';

const model = tf.sequential();
model.add(tf.layers.dense({ units: 1, inputShape: [2] }));
model.compile({ optimizer: 'sgd', loss: 'meanSquaredError' });

// Train with data
const xs = tf.tensor2d([[5, 42], [10, 80], [3, 15]]);
const ys = tf.tensor2d([[1], [2], [0]]); // 0 = not selected, 1 = selected, etc.

await model.fit(xs, ys, { epochs: 100 });

