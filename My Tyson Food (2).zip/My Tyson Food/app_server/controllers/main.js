/*GET Homepage*/
const index = (req, res)=> {
    res.render('index', {title: "My Tyson Food"});
};

module.exports = {
    index
}